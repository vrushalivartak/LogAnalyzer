﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfCustomControlLibrary1
{
    public class HierarchyView : Control
    {
        #region Property Title
        /// </summary>
        public int Title
        {
            get { return (int)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MyProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.Register("Title", typeof(string), typeof(HierarchyView), new PropertyMetadata(""));
        #endregion

        #region Property Message
        /// </summary>
        public int Message
        {
            get { return (int)GetValue(MessageProperty); }
            set { SetValue(MessageProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MyProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MessageProperty =
            DependencyProperty.Register("Message", typeof(string), typeof(HierarchyView), new PropertyMetadata(""));
        #endregion

        #region Event RowExpanded

        /*public static readonly RoutedEvent RowExpandedRoutedEvent =
        //EventManager.RegisterRoutedEvent("RowExpanded", RoutingStrategy.Bubble, typeof(TableViewRowDetailsEventHandler), typeof(CustomControl1));
        EventManager.RegisterRoutedEvent("RowExpanded", RoutingStrategy.Bubble, typeof(TableViewRowDetailsEventHandler), typeof(DialogBox));
        //CLR

        public event TableViewRowDetailsEventHandler RowExpanded
        {
            add { this.AddHandler(RowExpandedRoutedEvent, value); }
            remove { this.RemoveHandler(RowExpandedRoutedEvent, value); }
        }*/

        #endregion

        static HierarchyView()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(HierarchyView), new FrameworkPropertyMetadata(typeof(HierarchyView)));
        }

        Grid MainGrid = null;
        Label InputLabel = null;
        TextBox InputText = null;
        Button btnOk = null;
        Button btnCancel = null;
        TreeView WorkspaceView = null;


        public override void OnApplyTemplate()
        {
            MainGrid = GetTemplateChild("MainGrid") as Grid;
            WorkspaceView = GetTemplateChild("TreeView") as TreeView;
            //InputText = GetTemplateChild("InputText") as TextBox;
            
            CreateMainGrid();

            TreeViewItem ParentItem = new TreeViewItem();
            ParentItem.Header = "Parent";
            WorkspaceView.Items.Add(ParentItem);
            //  
            TreeViewItem Child1Item = new TreeViewItem();
            Child1Item.Header = "Child One";
            ParentItem.Items.Add(Child1Item);
            //  
            TreeViewItem Child2Item = new TreeViewItem();
            Child2Item.Header = "Child Two";
            ParentItem.Items.Add(Child2Item);
            TreeViewItem SubChild1Item = new TreeViewItem();
            SubChild1Item.Header = "Sub Child One";
            Child2Item.Items.Add(SubChild1Item);
            TreeViewItem SubChild2Item = new TreeViewItem();
            SubChild2Item.Header = "Sub Child Two";
            Child2Item.Items.Add(SubChild2Item);
            TreeViewItem SubChild3Item = new TreeViewItem();
            SubChild3Item.Header = "Sub Child Three";
            Child2Item.Items.Add(SubChild3Item);
            //  
            TreeViewItem Child3Item = new TreeViewItem();
            Child3Item.Header = "Child Three";
            ParentItem.Items.Add(Child3Item);

            
        }

        private void CreateMainGrid()
        {
            //Uncomment for MainGrid to load dynamically
            //MainGrid = new Grid();

            // Add one column for TreeView
            ColumnDefinition treeViewColumnDefinition = new ColumnDefinition();
            MainGrid.ColumnDefinitions.Add(treeViewColumnDefinition);

            // Add one row for buttons
            RowDefinition buttonRowDefinition = new RowDefinition();
            buttonRowDefinition.Height = GridLength.Auto;
            MainGrid.RowDefinitions.Add(buttonRowDefinition);

            // Add one row for TreeView
            RowDefinition treeViewRowDefinition = new RowDefinition();
            MainGrid.RowDefinitions.Add(treeViewRowDefinition);

            // Add buttons for gridview
            int buttonCount = CreateTreeViewButtons();

            // Span the MainDataGrid (log grid) across all columns
            Grid.SetColumnSpan(WorkspaceView, buttonCount + 1);

            Grid.SetColumn(WorkspaceView, 0);
            Grid.SetRow(WorkspaceView, 1);

            //Uncomment for MainGrid to load dynamically
            //AddChild(MainGrid);
        }

        private int CreateTreeViewButtons()
        {
            List<string> buttons = new List<string>();
            buttons.Add("sort");
            buttons.Add("filter");

            int btnIndex = 1;
            foreach (string strButton in buttons)
            {
                btnIndex++;

                // Add one column per button
                ColumnDefinition columnDefinition = new ColumnDefinition();
                columnDefinition.Width = new GridLength(20);
                MainGrid.ColumnDefinitions.Add(columnDefinition);

                // Add button
                Button btn = new Button();
                BitmapImage bmpImage = new BitmapImage(new Uri("C:\\Vrushali\\OLDnBIG\\Initiative\\LogAnalyzer\\LogAnalyzer\\Source\\WpfApp1\\Icons\\" + strButton + ".png", UriKind.Absolute));
                Image img = new Image();
                img.Source = bmpImage;
                img.Stretch = Stretch.Fill;
                btn.Content = img;
                btn.BorderThickness = new Thickness(0);
                btn.Margin = new Thickness(1.5);
                btn.Click += Btn_Click;
                MainGrid.Children.Add(btn);

                Grid.SetColumn(btn, btnIndex);
                Grid.SetRow(btn, 0);
            }

            return btnIndex;
        }

        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            // Grid button handling
        }

    }
}
