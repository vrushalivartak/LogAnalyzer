﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows;

namespace WpfCustomControlLibrary1
{
    public class TableViewRowDetailsArgs : RoutedEventArgs
    {
        public int DataGridLevel { get; set; }
        public DataGridRow Row { get; set; }
        public FrameworkElement DetailsElement { get; set; }

        public TableViewRowDetailsArgs(RoutedEvent routedEvent, object source) : base(routedEvent, source)
        {
        }
    }

    public delegate void TableViewRowDetailsEventHandler(object sender, TableViewRowDetailsArgs args);
}
