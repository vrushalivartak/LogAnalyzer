﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfCustomControlLibrary1
{
    public class TableView : Control
    {
        #region Property Level
        /// </summary>
        public int Level
        {
            get { return (int)GetValue(LevelProperty); }
            set { SetValue(LevelProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MyProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LevelProperty =
            DependencyProperty.Register("Level", typeof(int), typeof(TableView), new PropertyMetadata(0));

        public static int MaxLevel = 5;
        #endregion

        #region Event RowExpanded

        public static readonly RoutedEvent RowExpandedRoutedEvent =
        //EventManager.RegisterRoutedEvent("RowExpanded", RoutingStrategy.Bubble, typeof(TableViewRowDetailsEventHandler), typeof(CustomControl1));
        EventManager.RegisterRoutedEvent("RowExpanded", RoutingStrategy.Bubble,typeof(TableViewRowDetailsEventHandler), typeof(TableView));
        //CLR

        public event TableViewRowDetailsEventHandler RowExpanded
        {
            add { this.AddHandler(RowExpandedRoutedEvent, value); }
            remove { this.RemoveHandler(RowExpandedRoutedEvent, value); }
        }

        #endregion

        static TableView()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(TableView), new FrameworkPropertyMetadata(typeof(TableView)));
        }

        Grid MainGrid = null;
        DataGrid MainDataGrid = null;
        Expander RowExpander = null;
        public DataTable Logs = null;
        DataGridRow ParentRow = null;
        Button btnExpandCollapse = null;


        public override void OnApplyTemplate()
        {
            MainGrid = GetTemplateChild("MainGrid") as Grid;
            MainDataGrid = GetTemplateChild("MainDataGrid") as DataGrid;
            //RowExpander = GetTemplateChild("RowExpander") as Expander;

            TableView parentCC = null;

            if (this.Name != "ChildCustomTableView")
            {
                // Bind datasource for top level logs
                if (Logs != null)
                {
                    MainDataGrid.ItemsSource = Logs.DefaultView;
                }
            }
            else
            {
                // Get the Level of parent datagrid

                var currentParent = VisualTreeHelper.GetParent(this);

                do
                {
                    var frameworkElement = currentParent as FrameworkElement;
                    if (frameworkElement.GetType().Equals(typeof(TableView)))
                    {
                        parentCC = currentParent as TableView;
                        break;
                    }

                    currentParent = VisualTreeHelper.GetParent(currentParent);

                } while (currentParent != null);

                // Set the Level as parent level plus 1
                if (parentCC.Level == -1) // -1 indicates last level
                {
                    Level = parentCC.Level;
                }
                else
                {
                    Level = parentCC.Level + 1;
                }
            }

            if (Level != -1 && Level < MaxLevel)
            {
                //Setup the UI elements for displaying logs datagrid and datagrid buttons
                CreateMainGrid();
            }     
        }

        private void CreateMainGrid()
        {
            //Uncomment for MainGrid to load dynamically
            //MainGrid = new Grid();

            // Add one row and one column for gridview to display logs
            ColumnDefinition logsColumnDefinition = new ColumnDefinition();
            MainGrid.ColumnDefinitions.Add(logsColumnDefinition);

            // Add one row for buttons to operate on gridview
            RowDefinition buttonRowDefinition = new RowDefinition();
            buttonRowDefinition.Height = GridLength.Auto;
            MainGrid.RowDefinitions.Add(buttonRowDefinition);

            // Add one row for gridview to display logs
            RowDefinition logsRowDefinition = new RowDefinition();
            MainGrid.RowDefinitions.Add(logsRowDefinition);

            // Add buttons for gridview
            int buttonCount = CreateDataGridButtons();

            CreateMainDataGrid();

            // Span the MainDataGrid (log grid) across all columns
            Grid.SetColumnSpan(MainDataGrid, buttonCount);

            //Uncomment for MainGrid to load dynamically
            //AddChild(MainGrid);
        }

        private int CreateDataGridButtons()
        {
            List<string> buttons = new List<string>();
            buttons.Add("sort");
            buttons.Add("filter");
            buttons.Add("export");
            buttons.Add("group");

            int btnIndex = 1;
            foreach (string strButton in buttons)
            {
                btnIndex++;

                // Add one column per button
                ColumnDefinition columnDefinition = new ColumnDefinition();
                columnDefinition.Width = new GridLength(20);
                MainGrid.ColumnDefinitions.Add(columnDefinition);

                // Add button
                Button btn = new Button();
                BitmapImage bmpImage = new BitmapImage(new Uri("C:\\Vrushali\\OLDnBIG\\Initiative\\LogAnalyzer\\LogAnalyzer\\Source\\WpfApp1\\Icons\\" + strButton + ".png", UriKind.Absolute));
                Image img = new Image();
                img.Source = bmpImage;
                img.Stretch = Stretch.Fill;
                btn.Content = img;
                btn.BorderThickness = new Thickness(0);
                btn.Margin = new Thickness(1.5);
                btn.Click += Btn_Click;
                MainGrid.Children.Add(btn);

                Grid.SetColumn(btn, btnIndex);
                Grid.SetRow(btn, 0);
            }

            return btnIndex;
        }

        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            // Grid button handling
        }

        private void CreateMainDataGrid()
        {
            //Uncomment for MainDataGrid to load dynamically
            //MainDataGrid = new DataGrid();

            /*DataTemplate rowHeaderTemplate = new DataTemplate();
            rowHeaderTemplate.DataType = typeof(Expander);
            MainDataGrid.RowHeaderTemplate = rowHeaderTemplate;
            Expander expander = new Expander();
            expander.Expanded += Expander_Expanded;
            expander.Collapsed += Expander_Collapsed;*/

            //MainDataGrid.LoadingRowDetails += MainDataGrid_LoadingRowDetails;
            /*RowExpander.Expanded += RowExpander_Expanded;
            RowExpander.Collapsed += RowExpander_Collapsed;*/
            MainDataGrid.RowDetailsVisibilityChanged += MainDataGrid_RowDetailsVisibilityChanged;
            MainDataGrid.MouseUp += MainDataGrid_MouseUp;

            Grid.SetColumn(MainDataGrid, 0);
            Grid.SetRow(MainDataGrid, 1);

            /*DataTemplate template = new DataTemplate(typeof(DataGrid));
            MainDataGrid.RowDetailsTemplate = new DataTemplate(typeof(DataGrid));
            
            MainGrid.Children.Add(MainDataGrid);*/
        }

        private void MainDataGrid_MouseUp(object sender, MouseButtonEventArgs e)
        {
            DependencyObject dependencyObject = (DependencyObject)e.OriginalSource;

            DataGrid dataGrid = sender as DataGrid;

            DataGridRow row = GetDataGridRow(dependencyObject);

            if (row.DetailsVisibility == Visibility.Visible)
            {
                row.DetailsVisibility = Visibility.Collapsed;
            }
            else
            {
                row.DetailsVisibility = Visibility.Visible;
            }
            
            // Stop bubbling the event to parent grids
            e.Handled = true;
        }

        public static IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj)
       where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
                    if (child != null && child is T)
                    {
                        yield return (T)child;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }

        public static childItem FindVisualChild<childItem>(DependencyObject obj)
            where childItem : DependencyObject
        {
            foreach (childItem child in FindVisualChildren<childItem>(obj))
            {
                return child;
            }

            return null;
        }

        private DataGridRow GetDataGridRow(DependencyObject dependencyObject)
        {
            DataGridRow row = null;

            while ((dependencyObject != null) && !(dependencyObject is DataGridCell) && 
                !(dependencyObject is DataGridColumnHeader) && !(dependencyObject is DataGridRow))
            {
                dependencyObject = VisualTreeHelper.GetParent(dependencyObject);
            }

            if (dependencyObject != null)
            {
                if (dependencyObject is DataGridColumnHeader)
                {
                    DataGridColumnHeader columnHeader = dependencyObject as DataGridColumnHeader;
                    // do something
                }

                if (dependencyObject is DataGridRow)
                {
                    row = dependencyObject as DataGridRow;
                }

                if (dependencyObject is DataGridCell)
                {
                    DataGridCell cell = dependencyObject as DataGridCell;

                    // navigate further up the tree
                    while ((dependencyObject != null) && !(dependencyObject is DataGridRow))
                    {
                        dependencyObject = VisualTreeHelper.GetParent(dependencyObject);
                    }

                    row = dependencyObject as DataGridRow;

                    //var ple = (PlayListEntry)row.Item;

                    // From here you have access to all of the row.  
                    // Each column is suitable bound. 
                    // I can post the xaml if you are not sure.

                    //object value = ExtractBoundValue(row, cell);  //4

                    //int columnIndex = cell.Column.DisplayIndex;
                    //int rowIndex = FindRowIndex(row);

                    //var s = string.Format("Cell clicked [{0}, {1}] = {2}",rowIndex, columnIndex, value.ToString());
                }               
            }
            return row;
        }

        private void MainDataGrid_RowDetailsVisibilityChanged(object? sender, DataGridRowDetailsEventArgs e)
        {
            if (e.Row.DetailsVisibility.Equals(Visibility.Visible))
            {
                TableView childTable = e.DetailsElement as TableView;

                if (childTable.Level ==-1 || childTable.Level >= MaxLevel)
                {
                    e.Row.DetailsVisibility = Visibility.Collapsed;
                }
                else
                {
                    DataGrid dataGrid = sender as DataGrid;
                    TableViewRowDetailsArgs args  = new TableViewRowDetailsArgs(RowExpandedRoutedEvent, dataGrid)
                    {Row = e.Row, DetailsElement = e.DetailsElement, DataGridLevel = Level };
                    RaiseEvent(args);
                    childTable.MainDataGrid.ItemsSource = childTable.Logs.DefaultView;

                    // Span the ChildDataGrid (log grid) across all columns
                    Grid.SetColumnSpan(childTable, 5);

                    childTable.ParentRow = e.Row;
                }
            }
        }
    }
}
