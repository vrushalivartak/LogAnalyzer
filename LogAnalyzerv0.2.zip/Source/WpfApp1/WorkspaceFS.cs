﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml;

namespace WpfApp1
{

    //string metadatfilename = "C:\\workspace";

    internal class WorkspaceFS:Workspace
    {
        public WorkspaceFS(string name) {
            //string json = JsonConvert.SerializeObject(students, Formatting.Indented);
            List<string> list = new List<string>();
            list.Add(name);
            list.Add("1");
            list.Add("2");
            string jsonstring = JsonSerializer.Serialize(list);
        }
    }
}
