﻿using System;
using System.Dynamic;
using System.Runtime.Serialization;
using System.Windows;

namespace WpfApp1
{
    public class Log
    {
        public DateTime datetime { get; set; }

        public string source { get; set; }
        public string message { get; set; }

        public string processid { get; set; }
        public string threadid { get; set; }
        public string recordnumber { get; set; }

        public string level { get; set; }

        public Log(string dateTime, string recordnumber, string message)
        {
            datetime = DateTime.Now;
            this.recordnumber = recordnumber;
            this.message = message;
        }

    }
}