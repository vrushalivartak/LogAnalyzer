﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class LogFileVista:LogFile
    {
        public override int GetLogFileId()
        {
            Data data = new Data();
            return data.ExecuteScalar("SELECT Id from [LogFile] where filename='log20210225.txt'");
        }

        public override void GetLogs(int Id)
        {
            Data data = new Data();
            RawLogsView = data.ExecuteReader("select * from dbo.Log where Id<=10 AND logfileid=" + Id); //TBD - where LogFile name matches
        }
    }
}
