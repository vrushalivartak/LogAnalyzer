﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Data;

namespace WpfApp1
{
    internal class WorkspaceManager
    {
        public static string metadatafolderpath = "c:\\workspace";
        

        public WorkspaceManager() {
            //string[] metadatafiles = Directory.GetFiles(metadatafolderpath);
            Data data = new Data();
            //data.queryParams = new QueryParam[1];
            //data.queryParams[0] = new QueryParam("@username", "NCHAR", "");
            DataTable dt = data.ExecuteStoredProc("GetWorkspaces");
        }

        public static Workspace CreateNew(string name)
        {            
            List<Workspace> workspaces = new List<Workspace>();
            Workspace workspace = new Workspace(name);
            workspaces.Add(workspace);
            string jsonstring = JsonSerializer.Serialize(workspaces, new JsonSerializerOptions(){ WriteIndented = true }); ;
            StreamWriter streamWriter = new StreamWriter(metadatafolderpath + "\\" +  name + ".json");
            streamWriter.Write(jsonstring);
            streamWriter.Close();
            return workspace;
        }
    }
}
