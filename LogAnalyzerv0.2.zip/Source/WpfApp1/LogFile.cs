﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Data.SqlClient;

namespace WpfApp1
{
    internal class LogFile
    {

        public string FileName { get; set; } 

        /// <summary>
        /// Indicates whether the logfile is open in workspace
        /// </summary>
        public bool WorkspaceStatus = false;

        /// <summary>
        /// Indicates whether the logfile is loaded in memory
        /// </summary>
        public bool LoadedInMemory = false;

        /// <summary>
        /// Indicates whether the logfile analysis metadata is ready
        /// </summary>
        public bool MetadataReady = false;

        /// <summary>
        /// List of bookmarks
        /// </summary>
        public List<int> IndexedLogs;

        /// <summary>
        /// List of bookmarks
        /// </summary>
        public List<int> Bookmarks;

        /// <summary>
        /// List of bookmarks
        /// </summary>
        public List<int> Groups;

        /// <summary>
        /// The log lines in memory for viewing purpose
        /// Keep about 1000 lines in this view,
        /// refesh the view when viewing first 99 or last 99 log lines
        /// </summary>
        public DataTable RawLogsView;
        public DataTable TxLogsView;

        public LogFile() { RawLogsView = new DataTable(); }    
        public LogFile(string filename) {

            RawLogsView = new DataTable();
            TxLogsView = new DataTable();
            int id = GetLogFileId();
            if (id > 0)
            {
                GetLogs(id);
                GetTxLogs(id);
            }

            FileName = filename;
        }

        public virtual int GetLogFileId()
        {
            Data data = new Data();
            return data.ExecuteScalar("SELECT Id from [LogFile] where filename='log20210225.txt'");   
        }

        public virtual void GetLogs(int Id)
        {
            Data data = new Data();
            //RawLogsView = data.ExecuteReader("select * from dbo.Log where Id<=10 AND logfileid=" + Id); //TBD - where LogFile name matches
            // RawLogsView = data.ExecuteStoredProc("GetRawLogs", "@logfileid", SqlDbType.Int, 1, );
            data.queryParams = new QueryParam[2];
            data.queryParams[0] = new QueryParam("@logfileid", "Int", 1);
            data.queryParams[1] = new QueryParam("@startlogid", "Int", 1);
            RawLogsView = data.ExecuteStoredProc("GetRawLogs");
        }

        public virtual void GetTxLogs(int Id)
        {
            Data data = new Data();
            // RawLogsView = data.ExecuteReader("select * from dbo.Log where Id<=10 AND logfileid=" + Id); //TBD - where LogFile name matches
            data.queryParams = new QueryParam[2];
            data.queryParams[0] = new QueryParam("@logfileid", "Int", 1);
            data.queryParams[1] = new QueryParam("@startlogid", "Int", 1);
            TxLogsView = data.ExecuteStoredProc("GetTxLogs");
        }
    }
}
