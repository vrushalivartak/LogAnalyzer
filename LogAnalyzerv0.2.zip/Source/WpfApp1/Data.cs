﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace WpfApp1
{

    internal class QueryParam 
    {
        public string name;
        public string type;
        public object value;
        public QueryParam(string name, string type, object value) { this.name = name; this.type = type; this.value = value; }
    }
    
    internal class Data
    {
        private string sqlConnectionString = "Database=LogAnalysis;Server=INIDC-CQ8KFB3\\SQLEXPRESS;user=sa;password=Diebold@123";

        public QueryParam[] queryParams;
        
        public Data() 
        {
        }

        public int ExecuteScalar(string command)
        {
            DataTable dt = new DataTable();
            SqlConnection sqlConnection = new SqlConnection(sqlConnectionString);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(command);
            sqlCommand.Connection = sqlConnection;
            int rowcount = (int)sqlCommand.ExecuteScalar();
            sqlConnection.Close();
            return rowcount;
        }

        public DataTable ExecuteReader(string command)
        {
            DataTable dt = new DataTable();
            SqlConnection sqlConnection = new SqlConnection(sqlConnectionString);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(command); 
            sqlCommand.Connection = sqlConnection;
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            dt.Load(sqlDataReader);
            sqlConnection.Close();
            return dt;
        }

        public DataTable ExecuteStoredProc(string spname)
        {
            DataTable dt = new DataTable();
            SqlConnection sqlConnection = new SqlConnection(sqlConnectionString);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(spname);
            sqlCommand.Connection = sqlConnection;
            sqlCommand.CommandType = CommandType.StoredProcedure;
            if (queryParams!=null)
            foreach (QueryParam param in queryParams)
                sqlCommand.Parameters.Add(new SqlParameter(param.name, param.value)); // TBD
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            dt.Load(sqlDataReader);
            sqlConnection.Close();
            return dt;
        }

        private SqlDbType DbType(string type)
        {
            switch (type)
            {
                case "Int": return SqlDbType.Int;
            }
            return SqlDbType.VarChar;
        }
    }
}
