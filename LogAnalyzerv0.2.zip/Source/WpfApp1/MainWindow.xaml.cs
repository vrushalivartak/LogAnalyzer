﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfCustomControlLibrary1;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private Workspace activeworkspace;
 
        public MainWindow()
        {
            InitializeComponent();
            string theme = ConfigurationManager.AppSettings.Get("Theme");
            //MenuItem_Click(null, null);

            WorkspaceManager manager = new WorkspaceManager();
            HierarchyView WorkspaceView = new HierarchyView();
            
            Grid.SetColumn(WorkspaceView, 1);
            Grid.SetRow(WorkspaceView, 2);
            Grid.SetColumnSpan(WorkspaceView, 1);
            MainGrid.Children.Add(WorkspaceView);
        }


        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            MenuItem menuItem = (MenuItem)sender;
            LogFile lf = null;
            TableView ParentTableView;
            TableView TxView;
            HierarchyView WorkspaceView;

            switch (menuItem.Name)
            {
                case "MenuFileOpenLog":
                    OpenFileDialog openFileDialog = new OpenFileDialog();
                    openFileDialog.ShowDialog();
                    lf = new LogFile(openFileDialog.FileName);

                    //LogFile lf = new LogFile("");

                    ParentTableView = new TableView();
                    ParentTableView.Logs = lf.RawLogsView;
                    ParentTableView.RowExpanded += TableView_RowExpanded;
                    ParentTableView.Level = 0;
                    Grid.SetColumn(ParentTableView, 2);
                    Grid.SetRow(ParentTableView, 2);
                    Grid.SetColumnSpan(ParentTableView, 1);
                    MainGrid.Children.Add(ParentTableView);


                    WorkspaceView = new HierarchyView();
                    Grid.SetColumn(WorkspaceView, 1);
                    Grid.SetRow(WorkspaceView, 2);
                    Grid.SetColumnSpan(WorkspaceView, 1);
                    MainGrid.Children.Add(WorkspaceView);

                    break;

                case "MenuViewTransaction":
                    lf = new LogFile("");

                    ParentTableView = new TableView();
                    ParentTableView.Logs = lf.TxLogsView;
                    ParentTableView.RowExpanded += TableView_RowExpanded;
                    ParentTableView.Level = 0;
                    Grid.SetColumn(ParentTableView, 1);
                    Grid.SetRow(ParentTableView, 2);
                    Grid.SetColumnSpan(ParentTableView, 3);
                    MainGrid.Children.Add(ParentTableView);
                    break;

                case "MenuViewRaw":
                    lf = new LogFile("");

                    ParentTableView = new TableView();
                    ParentTableView.Logs = lf.TxLogsView;
                    ParentTableView.RowExpanded += TableView_RowExpanded;
                    ParentTableView.Level = 0;
                    Grid.SetColumn(ParentTableView, 1);
                    Grid.SetRow(ParentTableView, 2);
                    Grid.SetColumnSpan(ParentTableView, 3);
                    MainGrid.Children.Add(ParentTableView);
                    break;

                case "MenuFileNewWorkspace":
                    DialogBox d = new DialogBox();
                    //OpenFileDialog d = new OpenFileDialog();
                    //SaveFileDialog saveFileDialog/ = new SaveFileDialog();
                    //saveFileDialog.ShowDialog(this);
                    //string inputRead = new InputBox("text").ShowDialog();
                    //WorkspaceManager.CreateNew("workspacename");

                    activeworkspace = WorkspaceManager.CreateNew("workspacename");

                    break;

                default:
                    break;
                    
            }

            
        }

        private void TableView_RowExpanded(object sender, TableViewRowDetailsArgs args)
        {
            TableView childTable = args.DetailsElement as TableView;

            DataTable dtLogs = new DataTable();
            dtLogs.Columns.Add(new DataColumn("Name", typeof(string)));
            dtLogs.Columns.Add(new DataColumn("Id", typeof(string)));
            dtLogs.Rows.Add("Vrushali", "10");
            dtLogs.Rows.Add("Vedali", "0");

            childTable.Logs = dtLogs;

            // Span the ChildDataGrid (log grid) across all columns
            Grid.SetColumnSpan(childTable, 5);

        }
    }
}
