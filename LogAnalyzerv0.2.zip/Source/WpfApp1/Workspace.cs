﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class Workspace
    {
        /// <summary>
        /// List of all the logfiles which have been added/opened in workspace
        /// </summary>
        public string name { get; set; }
        public List<LogFile> LogFiles { get; set; }

        /// <summary>
        /// Indicates whether the logfile analysis metadata is ready
        /// </summary>
        public bool MetadataReady = false;

        public Workspace() { }
        public Workspace(string name) {
            this.name = name;
            LogFiles = new List<LogFile> { new LogFile("logfilename") };
        }
    }
}
