﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Documents.Serialization;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for CustomTableView.xaml
    /// </summary>
    public partial class CustomTableView : UserControl
    {
        public DataTable dtLogs = new DataTable();

        public int level { get; set; }
        
        //Uncomment for MainGrid to load dynamically
        //private Grid MainGrid;
        //Uncomment for MainDataGrid to load dynamically
        //private DataGrid MainDataGrid;

        public CustomTableView()
        {
            InitializeComponent();

            CreateMainGrid();

            //RefreshDisplayData();

        }

        /// <summary>
        /// Add one column per button
        /// Create and add new button
        /// Return the button count
        /// </summary>
        /// <returns></returns>
        private int CreateDataGridButtons()
        {
            List<string> buttons = new List<string>();
            buttons.Add("sort");
            buttons.Add("filter");
            buttons.Add("export");
            buttons.Add("group");

            int btnIndex = 0;
            foreach (string strButton in buttons)
            {
                btnIndex++;

                // Add one column per button
                ColumnDefinition columnDefinition = new ColumnDefinition();
                columnDefinition.Width = new GridLength(20);
                MainGrid.ColumnDefinitions.Add(columnDefinition);

                // Add button
                Button btn = new Button();
                BitmapImage bmpImage = new BitmapImage(new Uri("C:\\Vrushali\\Projects\\Initiative\\LogAnalyzer\\Source\\WpfApp1\\Icons\\"+strButton+".png", UriKind.Absolute));
                Image img = new Image();
                img.Source = bmpImage;
                img.Stretch = Stretch.Fill;
                btn.Content = img;
                btn.BorderThickness = new Thickness(0);
                btn.Margin = new Thickness(1.5);
                MainGrid.Children.Add(btn);

                Grid.SetColumn(btn, btnIndex);
                Grid.SetRow(btn, 0);
            }

            return btnIndex;
        }

        public void RefreshDisplayData()
        {
            /*
            LogFile lf = new LogFile("");
            dtLogs = lf.ActiveLogsView;
            //MainCustomTableView.RefreshDisplayData();
            */
            MainDataGrid.ItemsSource = dtLogs.DefaultView;
            MainDataGrid.BorderBrush = Brushes.Gray;
        }

        private void CreateMainGrid()
        {
            //Uncomment for MainGrid to load dynamically
            //MainGrid = new Grid();

            // Add one row and one column for gridview to display logs
            ColumnDefinition logsColumnDefinition = new ColumnDefinition();
            
            MainGrid.ColumnDefinitions.Add(logsColumnDefinition);

            // Add one row for buttons to operate on gridview
            RowDefinition buttonRowDefinition = new RowDefinition();
            buttonRowDefinition.Height = GridLength.Auto;
            MainGrid.RowDefinitions.Add(buttonRowDefinition);

            // Add one row for gridview to display logs
            RowDefinition logsRowDefinition = new RowDefinition();
            MainGrid.RowDefinitions.Add(logsRowDefinition);

            // Add buttons for gridview
            int buttonCount = CreateDataGridButtons();

            CreateMainDataGrid();

            // Span the MainDataGrid (log grid) across all columns
            Grid.SetColumnSpan(MainDataGrid, buttonCount+1);

            //Uncomment for MainGrid to load dynamically
            //AddChild(MainGrid);
        }

        private void CreateMainDataGrid()
        {
            //Uncomment for MainDataGrid to load dynamically
            //MainDataGrid = new DataGrid();

            /*DataTemplate rowHeaderTemplate = new DataTemplate();
            rowHeaderTemplate.DataType = typeof(Expander);
            MainDataGrid.RowHeaderTemplate = rowHeaderTemplate;
            Expander expander = new Expander();
            expander.Expanded += Expander_Expanded;
            expander.Collapsed += Expander_Collapsed;*/

            //MainDataGrid.LoadingRowDetails += MainDataGrid_LoadingRowDetails;
            if (this.level == 0)
            {
                MainDataGrid.RowDetailsVisibilityChanged += MainDataGrid_RowDetailsVisibilityChanged;
            }
            Grid.SetColumn(MainDataGrid, 0);
            Grid.SetRow(MainDataGrid, 1);

            /*DataTemplate template = new DataTemplate(typeof(DataGrid));
            MainDataGrid.RowDetailsTemplate = new DataTemplate(typeof(DataGrid));
            
            MainGrid.Children.Add(MainDataGrid);*/
        }

        private void CreateChildGrid()
        {
            Grid childGrid = new Grid();

            // Add one column for leftmargin
            ColumnDefinition leftmarginColumnDefinition = new ColumnDefinition();
            leftmarginColumnDefinition.Width = new GridLength(5);
            childGrid.ColumnDefinitions.Add(leftmarginColumnDefinition);

            // Add one column for gridview to display logs
            ColumnDefinition logsColumnDefinition = new ColumnDefinition();
            childGrid.ColumnDefinitions.Add(logsColumnDefinition);

            // Add one column for rightmargin
            ColumnDefinition rightmarginColumnDefinition = new ColumnDefinition();
            rightmarginColumnDefinition.Width = new GridLength(5);
            childGrid.ColumnDefinitions.Add(rightmarginColumnDefinition);

            // Add one row for topmargin
            RowDefinition topmarginRowDefinition = new RowDefinition();
            topmarginRowDefinition.Height = new GridLength(5);
            childGrid.RowDefinitions.Add(topmarginRowDefinition);

            // Add one row for gridview to display logs
            RowDefinition logsRowDefinition = new RowDefinition();
            logsRowDefinition.Height = GridLength.Auto;
            childGrid.RowDefinitions.Add(logsRowDefinition);

            // Add one row for bottommargin
            RowDefinition bottommarginRowDefinition = new RowDefinition();
            bottommarginRowDefinition.Height = new GridLength(5);
            childGrid.RowDefinitions.Add(bottommarginRowDefinition);

            // customTableView
            CustomTableView customTableView = new CustomTableView();
            customTableView.Name = "ChildDataView";
            Grid.SetRow(customTableView, 1);
            Grid.SetColumn(customTableView, 1);
            childGrid.Children.Add(customTableView);
        }

        private void Row_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            // execute some code
        }

        private void MainDataGrid_Scroll(object sender, System.Windows.Controls.Primitives.ScrollEventArgs e)
        {

        }

        private void MainDataGrid_MouseDown(object sender, MouseButtonEventArgs e)
        {
        }

        private void MainDataGrid_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
        }

        private void MainDataGrid_RowDetailsVisibilityChanged(object sender, DataGridRowDetailsEventArgs e)
        {
            DataGrid dataGrid = sender as DataGrid;
            if (e.Row.Visibility.Equals(Visibility.Visible))
            {
                CustomTableView childGrid = e.DetailsElement as CustomTableView;
                childGrid.level = this.level++;
                //Grid grid = e.DetailsElement as Grid;
                //CustomTableView childGrid = grid.Children[0] as CustomTableView;

                LogFile lf = new LogFile("");
                childGrid.dtLogs = lf.RawLogsView;

                // Span the ChildDataGrid (log grid) across all columns
                Grid.SetColumnSpan(childGrid, 5);
                childGrid.RefreshDisplayData();
            }
        }

        private void Expander_Expanded(object sender, RoutedEventArgs e)
        {

            for (var vis = sender as Visual; vis != null; vis = VisualTreeHelper.GetParent(vis) as Visual)
                if (vis is DataGridRow)
                {
                    var row = (DataGridRow)vis;
                    row.DetailsVisibility = row.DetailsVisibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
                    break;
                }
       }

        private void Expander_Collapsed(object sender, RoutedEventArgs e)
        {
            for (var vis = sender as Visual; vis != null; vis = VisualTreeHelper.GetParent(vis) as Visual)
                if (vis is DataGridRow)
                {
                    var row = (DataGridRow)vis;
                    row.DetailsVisibility = row.DetailsVisibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
                    break;
                }
        }
    }
}
