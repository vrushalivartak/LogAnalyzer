﻿

BEGIN TRANSACTION
DECLARE @filealreadyindexed INTEGER
select @filealreadyindexed=isindexed from dbo.LogFile where Id = 1;
if @filealreadyindexed = 0
BEGIN
	with X(id, idx, isEnd, ts) as (
		select 
			Id, 
			ROW_NUMBER() over (order by Id asc) as idx,
			CASE WHEN logtext like 'session start%' THEN 0 ELSE 1 End as isEnd,
			timestamp from [dbo].[Log] as ts
		where logtext like 'session start%' or logtext like 'session end%'
	)
	
	insert into dbo.Sequence (sequencedefinitionid, logfileid, startlogid, endlogid, isEnd)
		select 1 as sequencedefinitionid, 1 as logfileid,
		x1.Id as startlogid, 
		case when X2.isEnd = 1 THEN x2.Id ELSE x2.Id - 1 END as endlogid,
		x2.isEnd as isEnd
	from x x1 join x x2 
		on X1.isEnd = 0 AND x1.idx + 1 = x2.idx;
	update dbo.LogFile set isindexed = 1 where Id = 1;
END
COMMIT

