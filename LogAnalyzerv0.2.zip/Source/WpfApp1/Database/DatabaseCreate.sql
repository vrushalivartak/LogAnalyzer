﻿

DROP TABLE [dbo].[Sequence];
DROP TABLE [dbo].[SequenceDefinition];
DROP TABLE [dbo].[Log];
DROP TABLE [dbo].[LogFile];
DROP TABLE [dbo].[LogFileType];
DROP TABLE [dbo].[WorkspaceFiles];
DROP TABLE [dbo].[Workspace];


CREATE TABLE [dbo].[Workspace] (
    [Id]             INT         NOT NULL   IDENTITY(1,1),
	[name]           NCHAR (50)  NOT NULL,
	[username]       NCHAR (50)  NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE TABLE [dbo].[WorkspaceFiles] (
	[workspaceid]    INT         NOT NULL,
    [logfileid]      INT         NOT NULL,
	UNIQUE ([workspaceid], [logfileid])
);

CREATE TABLE [dbo].[LogFileType] (
    [Id]             INT         NOT NULL   IDENTITY(1,1),
    [logtype]        NCHAR (50)  NOT NULL,
    [filetype]       NCHAR (50)  NOT NULL,
    [filenameformat] NCHAR (50)  NOT NULL,
    [headers]        NCHAR (200) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE TABLE [dbo].[LogFile] (
    [Id]             INT         NOT NULL   IDENTITY(1,1),
    [logfiletypeid]  INT         NOT NULL,
    [filename]       NCHAR (100) NOT NULL,
    [loadedon]       DATETIME    NOT NULL,
	[isindexed]      INT    NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([logfiletypeid]) REFERENCES [dbo].[LogFileType] ([Id])
);

CREATE TABLE [dbo].[Log] (
    [Id]            INT        NOT NULL   IDENTITY(1,1),
    [logfileid]     INT        NOT NULL,
    [timestamp]     DATETIME   NOT NULL,
    [logtext]       NTEXT      NOT NULL,
    [source]        NCHAR (10) NULL,
    [processid]     NCHAR (10) NULL,
    [threadid]      NCHAR (10) NULL,
    [correlationid] NCHAR (10) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([logfileid]) REFERENCES [dbo].[LogFile] ([Id])
);


CREATE TABLE [dbo].[SequenceDefinition] (
    [Id]               INT        NOT NULL   IDENTITY(1,1),
    [name]             NCHAR (50) NULL,
    [definition]       NTEXT      NOT NULL,
    [detaildefinition] NTEXT      NOT NULL,
	[start]       NTEXT      NOT NULL,
	[end]       NTEXT      NOT NULL,
    [level]            INT        DEFAULT 1,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE TABLE [dbo].[Sequence] (
    [Id]                   INT NOT NULL   IDENTITY(1,1),
    [sequencedefinitionid] INT NOT NULL,
    [logfileid]            INT NOT NULL,
    [startlogid]           INT NOT NULL,
    [endlogid]             INT NOT NULL,
	[isEnd]                INT NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([sequencedefinitionid]) REFERENCES [dbo].[SequenceDefinition] ([Id]),
    FOREIGN KEY ([logfileid]) REFERENCES [dbo].[LogFile] ([Id]),
    FOREIGN KEY ([startlogid]) REFERENCES [dbo].[Log] ([Id]),
    FOREIGN KEY ([endlogid]) REFERENCES [dbo].[Log] ([Id])
);


