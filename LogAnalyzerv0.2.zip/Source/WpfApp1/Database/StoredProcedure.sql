﻿
-----------------------------------------------------------------------------------------
DROP PROCEDURE GetWorkspaces
GO

CREATE PROCEDURE GetWorkspaces
AS
select TOP 50 name from dbo.Workspace
GO
-----------------------------------------------------------------------------------------
DROP PROCEDURE GetTxLogs
GO

CREATE PROCEDURE GetTxLogs @logfileid INTEGER, @startlogid INTEGER
AS
select TOP 50 dbo.Log.* from dbo.Log JOIN dbo.Sequence ON Sequence.logfileid = Log.logfileid AND log.Id = Sequence.startlogid
where sequencedefinitionid=1 
GO

-----------------------------------------------------------------------------------------
DROP PROCEDURE GetRawLogs
GO

CREATE PROCEDURE GetRawLogs @logfileid INTEGER, @startlogid INTEGER
AS
select TOP 50 * from dbo.Log where logfileid=@logfileid AND Id>=@startlogid ORDER BY Id
GO

-----------------------------------------------------------------------------------------
DROP PROCEDURE IndexLogFile
GO

CREATE PROCEDURE IndexLogFile @logfileid INTEGER
AS
BEGIN TRANSACTION
DECLARE @filealreadyindexed INTEGER
select @filealreadyindexed=isindexed from dbo.LogFile where Id = @logfileid;
if @filealreadyindexed = 0
BEGIN
	with X(id, idx, isEnd, ts) as (
		select 
			Id, 
			ROW_NUMBER() over (order by Id asc) as idx,
			CASE WHEN logtext like 'session start%' THEN 0 ELSE 1 End as isEnd,
			timestamp from [dbo].[Log] as ts
		where logtext like 'session start%' or logtext like 'session end%'
	)
	
	insert into dbo.Sequence (sequencedefinitionid, logfileid, startlogid, endlogid, isEnd)
		select 1 as sequencedefinitionid, @logfileid as logfileid,
		x1.Id as startlogid, 
		case when X2.isEnd = 1 THEN x2.Id ELSE x2.Id - 1 END as endlogid,
		x2.isEnd as isEnd
	from x x1 join x x2 
		on X1.isEnd = 0 AND x1.idx + 1 = x2.idx;
	update dbo.LogFile set isindexed = 1 where Id = @logfileid;
END
COMMIT
GO

