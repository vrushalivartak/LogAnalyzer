﻿
INSERT INTO [dbo].[LogFileType](logtype, filetype, filenameformat) VALUES('Transaction Logs', 'csv', 'regex');

INSERT INTO [dbo].[LogFile](logfiletypeid, filename, loadedon) VALUES(1, 'log20210225.txt', SYSDATETIME());
