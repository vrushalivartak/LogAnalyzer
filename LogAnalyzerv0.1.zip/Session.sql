﻿
with X(id, idx, isEnd, ts) as (
	select 
		Id, 
		ROW_NUMBER() over (order by Id asc) as idx,
		CASE WHEN logtext like 'session start%' THEN 0 ELSE 1 End as isEnd,
		timestamp from [dbo].[Log]
	where logtext like 'session start%' or logtext like 'session end%'
)
select 
	x1.Id as StartId, 
	case when X2.isEnd = 1 THEN x2.Id ELSE x2.Id - 1 END as EndId,
	x2.isEnd
from x x1 join x x2 
	on X1.isEnd = 0 AND x1.idx + 1 = x2.idx

	select * from Log where Id > 840 and Id < 970
